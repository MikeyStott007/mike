import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, TreePine, Tent, Sun, Hotel, Cog } from "lucide-react";

const services = [
  {
    title: "Home Design & Building",
    description: "Custom home design and construction, including full architectural plans.",
    icon: Home
  },
  {
    title: "Tiny Cabins & Homes",
    description: "Compact, custom-built cabins and tiny homes, ideal for minimalist living.",
    icon: Tent
  },
  {
    title: "Outdoor Living Structures",
    description: "Decks, saunas, hot tubs, and pump houses for residential upgrades.",
    icon: TreePine
  },
  {
    title: "Off-Grid Solutions",
    description: "Sustainable, self-sufficient living solutions tailored to your needs.",
    icon: Sun
  },
  {
    title: "Airbnb & Investment",
    description: "Full property setups optimized for rental income or resale value.",
    icon: Hotel
  },
  {
    title: "Expert Consultation",
    description: "Leverage our 25+ years of timber industry expertise.",
    icon: Cog
  }
];

export function Services() {
  return (
    <section id="services" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Card key={index}>
              <CardHeader>
                <service.icon className="h-8 w-8 text-primary mb-2" />
                <CardTitle>{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
