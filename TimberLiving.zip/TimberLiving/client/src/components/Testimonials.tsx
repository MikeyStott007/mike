import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";

const testimonials = [
  {
    name: "John Smith",
    role: "Homeowner",
    content: "Plett Timbers Living turned our dream home into reality. Their attention to detail and craftsmanship is unmatched."
  },
  {
    name: "Sarah Johnson",
    role: "Property Investor",
    content: "The team's expertise in Airbnb properties has been invaluable. Our cabin has become a top-rated destination."
  },
  {
    name: "Mike Wilson",
    role: "Eco-Living Enthusiast",
    content: "Their off-grid solutions are innovative and sustainable. We couldn't be happier with our self-sufficient home."
  }
];

export function Testimonials() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">What Our Clients Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <Quote className="h-8 w-8 text-primary mb-4" />
                <p className="text-muted-foreground mb-4">{testimonial.content}</p>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
