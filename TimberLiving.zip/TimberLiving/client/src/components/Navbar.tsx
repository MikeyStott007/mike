import { Link } from "wouter";

export function Navbar() {
  return (
    <nav className="fixed w-full bg-background/95 backdrop-blur z-50 border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="text-xl font-semibold text-primary">Plett Timbers Living</a>
        </Link>
        <div className="hidden md:flex space-x-6">
          <Link href="#services">
            <a className="text-muted-foreground hover:text-primary transition">Services</a>
          </Link>
          <Link href="#portfolio">
            <a className="text-muted-foreground hover:text-primary transition">Portfolio</a>
          </Link>
          <Link href="#about">
            <a className="text-muted-foreground hover:text-primary transition">About</a>
          </Link>
          <Link href="#contact">
            <a className="text-muted-foreground hover:text-primary transition">Contact</a>
          </Link>
        </div>
      </div>
    </nav>
  );
}
