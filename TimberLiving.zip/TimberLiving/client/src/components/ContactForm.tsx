import { Button } from "@/components/ui/button";

export function ContactForm() {
  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-12">Contact Us</h2>
          <p className="text-muted-foreground mb-8">
            Ready to start your project? Get in touch with us today!
          </p>
          <Button size="lg" asChild>
            <a href="mailto:info@pletttimbersliving.com" className="inline-flex items-center">
              Contact Us
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}