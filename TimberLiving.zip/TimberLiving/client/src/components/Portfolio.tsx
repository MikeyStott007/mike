import { Card, CardContent } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";

const projects = [
  {
    title: "Modern Timber Home",
    description: "Custom-built 3-bedroom timber frame house with panoramic views.",
    image: "https://images.unsplash.com/photo-1542718610-a1d656d1884c"
  },
  {
    title: "Luxury Cabin",
    description: "Compact yet luxurious off-grid cabin with sustainable features.",
    image: "https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8"
  },
  {
    title: "Outdoor Living",
    description: "Custom deck and outdoor entertainment area with hot tub.",
    image: "https://images.unsplash.com/photo-1591825729269-caeb344f6df2"
  }
];

export function Portfolio() {
  return (
    <section id="portfolio" className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Card key={index} className="overflow-hidden">
              <AspectRatio ratio={16/9}>
                <img
                  src={project.image}
                  alt={project.title}
                  className="object-cover w-full h-full"
                />
              </AspectRatio>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{project.title}</h3>
                <p className="text-sm text-muted-foreground">{project.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
