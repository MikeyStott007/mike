import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <div className="relative min-h-screen flex items-center">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            Crafting Timber Dreams Into Reality
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            With over 25 years of timber industry experience, we create beautiful, sustainable homes that stand the test of time.
          </p>
          <div className="flex gap-4">
            <Button size="lg" asChild>
              <a href="#contact">Get Started</a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="#portfolio">View Our Work</a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
